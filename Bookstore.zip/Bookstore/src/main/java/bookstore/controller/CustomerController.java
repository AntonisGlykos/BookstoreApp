/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore.controller;

import bookstore.entity.Category;
import bookstore.entity.Country;
import bookstore.entity.Customer;
import bookstore.repo.CategoryRepo;
import bookstore.repo.CountryRepo;
import bookstore.repo.CustomerRepo;
import bookstore.service.UserService;
import java.security.Principal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 *
 * @author Dell
 */
@RequestMapping("/customer")
@Controller
public class CustomerController {
    
    @Autowired
    CustomerRepo customerRepo;
    
    @Autowired
    CountryRepo countryRepo;
  
    @Autowired
    UserService userService;

    @GetMapping
    public String customerAccount(Principal principal, Model model){
        Customer customer = customerRepo.findByUsername(principal.getName());
        
        model.addAttribute("customer", customer);
            
        return "customer-account";
    }
    
    @GetMapping("/update")
    public String showUpdateCustomerForm(@RequestParam("id") int id, Model model){
        
        Customer customer = customerRepo.findById(id).get();
        List<Country> countries = countryRepo.findAll();
        
        model.addAttribute("countries", countries);
        
        model.addAttribute("customerToEdit", customer);
        
        return "customer-update-customer";
    }
    
    @PostMapping("/update")
    public String updateCustomer(Customer customer, RedirectAttributes attributes){
        
        userService.saveCustomer(customer);
        
        String successMessage = "Customer "+ customer.getFirstname()+" "+customer.getLastname()+" successfully updated!!";
        attributes.addFlashAttribute("successMessage", successMessage);
       
        return "redirect:/customer";
    }
    
    @RequestMapping("/cartlist")
    public String showCartList (@RequestParam("id") int id, Model model)  {
        Customer customer=customerRepo.findById(id).get();
        model.addAttribute("customer",customer);
        return "cartlist";
    }
}




